
  

for (let i= 0; i < 10; i++ ) {
    console.log(i+1)
}
function de1a10() {
    for (let i= 0; i < 100; i++ ) {
    console.log(i+1)
}
}


function pedirNombre (){
    let nombre = prompt ("ingrese un nombre")
    console.log("nombre" +nombre +"ingresado")
}
 pedirNombre();
 pedirNombre();
 pedirNombre();

 function suma (numero1,numero2)
 { console.log (numero1+ numero2)}
 suma ( 5,10)


 
 function suma ( numero1 , numero2)
 { return  numero1+ numero2}
 let numero1 = parseFloat ( prompt ("ingresa un numero")) 
 let numero2 = parseFloat ( prompt ("ingresa un numero"))
let resultado = suma ( numero1,numero2)
console.log(resultado)


function precio_descuento (numero3, numero4){
    return (numero3 - (numero3 * numero4 )) }
 let numero3 = parseFloat (prompt("ingrese monto"))
 let numero4 = 0.10
 alert ( "su producto con descuento cuesta $"+ (numero3 - (numero3*numero4)))


//variable local
function sumar(primerNumero, segundoNumero) {
    let resultado2 = primerNumero + segundoNumero;
}
let primerNumero = 20
let segundoNumero = 20
console.log(resultado2 = (primerNumero+segundoNumero));


//constante global

const iva = 0.21; 

function sumariva ( producto){
    return productos * iva}
    let productos = 2000
console.log (sumariva (100))

function calcularIva(precioCosto) {
   return (precioConIva * 0.21)}
   let precioConIva= 2000
   console.log (calcularIva ( precioConIva * 0.21))

 ivaM= iva.toFixed(2);

 alert("El IVA del producto ingresado es: "+ivaM); 
 console.log("El IVA del producto ingresado es: "+ivaM); 
  document.write("<h3> El IVA del producto ingresado es: "+iva+"</h3>");


function SumarIva (precioCosto){
    return (precioCosto + (precioCosto * 0.21));
}
let precioCosto = 10
console.log ( SumarIva (precioCosto + (precioCosto * 0.21)))
 var precioConiva = SumarIva(precioCosto); 
 let precioConIvaM = precioConIva.toFixed(2);
 alert("El precio del producto con IVA incluido es: "+precioConIvaM); 
 console.log("El precio del producto con IVA incluido es: "+precioConIvaM); 
  document.write("<h3> El precio del producto con IVA incluido es: "+precioConIvaM+"</h3>")

 function Calculaprecioventa(precioConIva) { 
  return (precioConIva * 1.25); }
console.log (Calculaprecioventa (precioConIva * 1.25) )
 var precioVenta = Calculaprecioventa(precioConIva); 
 let precioVentaM= precioVenta.toFixed(2);
 alert("El precio Sugerido de venta del producto es: "+precioVentaM); 
 console.log("El precio Sugerido de venta del producto es: "+precioVentaM); 
  document.write("<h3> El precio Sugerido de venta del producto es: "+precioVentaM+"</h3>")
